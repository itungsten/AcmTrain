请勿使用Dev cpp阅读代码（就他中文乱码）

clion
notepad
vim
vs
都可